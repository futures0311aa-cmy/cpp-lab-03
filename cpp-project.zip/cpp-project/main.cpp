
#include <iostream>
using namespace std;

int main() {
    // Declare variables
    char grade;
    double fee;

    // Take input from the user
    cout << "Enter grade: ";
    cin >> grade;

    cout << "Enter fee: ";
    cin >> fee;

    // Display stored values
    cout << "\nStudent Fee Information" << endl;
    cout << "-----------------------" << endl;
    cout << "Grade: " << grade << endl;
    cout << "Fee: " << fee << endl;

    return 0;
}
